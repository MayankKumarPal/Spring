package com.example.transaction.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.example.transaction.dto.Transactions;
import com.example.transaction.repository.TransactionRepository;
import com.example.transaction.service.TransactionService;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = TransactionController.class)
public class TransactionControllerTest {
	@MockBean
	private TransactionRepository transactionRepository;

	@MockBean
	private TransactionService transactionService;

	@InjectMocks
	private TransactionController transactionController;

	private MockMvc mockMvc;
	private Transactions transactions1;
	private String command = "command";
	private String dummy1 = "dummy1";

	public void transactions1() {
		transactions1 = new Transactions();
		transactions1.setId(9);
		transactions1.setAccountNumber(99999999);
		transactions1.setAccountName(dummy1);
		transactions1.setValueDate(LocalDate.now());
		transactions1.setCurrency(dummy1);
		transactions1.setDebitAmount(0);
		transactions1.setCreditAmount(0);
		transactions1.setType(dummy1);
		transactions1.setTransactionNarrative(dummy1);
	}

	@Before
	public void setUp() {
		transactions1();
	}

	@Test
	public void testTransactionGet() throws Exception {
		this.mockMvc.perform(get("/user/fetch")).andExpect(status().isOk()).andExpect(model().attributeExists(command))
				.andExpect(view().name("register")).andDo(print());
	}

}
