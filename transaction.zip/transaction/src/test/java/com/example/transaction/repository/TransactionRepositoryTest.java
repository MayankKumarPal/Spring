package com.example.transaction.repository;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.transaction.dto.Transactions;
import com.example.transaction.entity.TransactionsEntity;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class TransactionRepositoryTest {
	@Mock
	private TransactionRepository transactionRepository;
	private Transactions transactions1;

	private String dummy1 = "dummy1";

	public void transactions1() {
		transactions1 = new Transactions();
		transactions1.setId(9);
		transactions1.setAccountNumber(9999999);
		transactions1.setAccountName(dummy1);
		transactions1.setValueDate(LocalDate.now());
		transactions1.setCurrency(dummy1);
		transactions1.setDebitAmount(0);
		transactions1.setCreditAmount(0);
		transactions1.setType(dummy1);
		transactions1.setTransactionNarrative(dummy1);
	}

	@Before
	public void setUp() {
		transactions1();
	}

	@Test
	public void saveAndFlushTest() {
		TransactionsEntity transactionsEntity1 = new TransactionsEntity();
		transactionsEntity1.setAccountName(transactions1.getAccountName());
		transactionsEntity1.setAccountNumber(transactions1.getAccountNumber());
		transactionsEntity1.setValueDate(transactions1.getValueDate());
		transactionsEntity1.setCurrency(transactions1.getCurrency());
		transactionsEntity1.setDebitAmount(transactions1.getDebitAmount());
		transactionsEntity1.setCreditAmount(transactions1.getCreditAmount());
		transactionsEntity1.setType(transactions1.getType());
		transactionsEntity1.setTransactionNarrative(transactions1.getTransactionNarrative());
	}

	
}
