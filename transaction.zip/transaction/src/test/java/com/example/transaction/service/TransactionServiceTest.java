package com.example.transaction.service;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;

import com.example.transaction.dto.Transactions;
import com.example.transaction.entity.TransactionsEntity;
import com.example.transaction.repository.TransactionRepository;

@ContextConfiguration
public class TransactionServiceTest {
	@Mock
	private TransactionRepository transactionRepository;

	@InjectMocks
	private TransactionService transactionService;

	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	Transactions transactions = new Transactions();
	TransactionsEntity transactionsEntity = new TransactionsEntity();

	public void initilizeTransaction() {
		transactions.setId(123);
		transactions.setAccountName("ABCD");
		transactions.setAccountNumber(9999999);
		transactions.setValueDate(LocalDate.now());
		transactions.setDebitAmount(0);
		transactions.setCurrency("SGD");
		transactions.setCreditAmount(9999);
		transactions.setType("Credit");
		transactions.setTransactionNarrative(" ");
		transactionsEntity.setId(transactions.getId());
		transactionsEntity.setAccountName(transactions.getAccountName());
		transactionsEntity.setAccountNumber(transactions.getAccountNumber());
		transactionsEntity.setValueDate(transactions.getValueDate());
		transactionsEntity.setDebitAmount(transactions.getDebitAmount());
		transactionsEntity.setCreditAmount(transactions.getCreditAmount());
		transactionsEntity.setCurrency(transactions.getCurrency());
		transactionsEntity.setType(transactions.getType());
		transactionsEntity.setTransactionNarrative(transactions.getTransactionNarrative());
	}

	@Before
	public void initialWork() {
		MockitoAnnotations.initMocks(this);
		initilizeTransaction();
	}

}
