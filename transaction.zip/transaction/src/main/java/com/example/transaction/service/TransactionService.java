package com.example.transaction.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.transaction.entity.TransactionsEntity;
import com.example.transaction.entity.UserAccountEntity;
import com.example.transaction.repository.TransactionRepository;
import com.example.transaction.repository.UserAccountRepository;

@Service
public class TransactionService {
	@Autowired
	private TransactionRepository transactionRepository;
	
	@Autowired
	private UserAccountRepository userAccountRepository;
	
	public List<UserAccountEntity> getAllUser(){
		return userAccountRepository.findAll();
	}
	
	public List<TransactionsEntity> viewTransactionDetail(int accountNumber)
	{
		List<TransactionsEntity> trans=transactionRepository.findByAccountNumber(accountNumber);
		
		System.out.println(trans);
		return trans;
	
	}
}
