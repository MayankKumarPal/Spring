package com.example.transaction.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
public class TransactionsEntity {
	@Id
	private int id;
	private int accountNumber;
	private String accountName;
	private LocalDate valueDate;
	private String currency;
	private int debitAmount;
	private double creditAmount;
	private String type;
	private String transactionNarrative;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public LocalDate getValueDate() {
		return valueDate;
	}
	public void setValueDate(LocalDate valueDate) {
		this.valueDate = valueDate;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public int getDebitAmount() {
		return debitAmount;
	}
	public void setDebitAmount(int debitAmount) {
		this.debitAmount = debitAmount;
	}
	public double getCreditAmount() {
		return creditAmount;
	}
	public void setCreditAmount(double creditAmount) {
		this.creditAmount = creditAmount;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTransactionNarrative() {
		return transactionNarrative;
	}
	public void setTransactionNarrative(String transactionNarrative) {
		this.transactionNarrative = transactionNarrative;
	}
	public TransactionsEntity() {
		super();
	}
	public TransactionsEntity(int id, int accountNumber, String accountName, LocalDate valueDate, String currency,
			int debitAmount, double creditAmount, String type, String transactionNarrative) {
		super();
		this.id = id;
		this.accountNumber = accountNumber;
		this.accountName = accountName;
		this.valueDate = valueDate;
		this.currency = currency;
		this.debitAmount = debitAmount;
		this.creditAmount = creditAmount;
		this.type = type;
		this.transactionNarrative = transactionNarrative;
	}
	
	
	

}
