package com.example.transaction.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.transaction.entity.TransactionsEntity;
import com.example.transaction.entity.UserAccountEntity;
import com.example.transaction.service.TransactionService;

@RestController
@RequestMapping("/user")
public class TransactionController {

	@Autowired
	private TransactionService transactionService;
	
	@GetMapping("/fetch")
	public List<UserAccountEntity> getAllUser(){
		return transactionService.getAllUser();
	}
	
	@GetMapping("/transaction/{accountNumber}")
	public List<TransactionsEntity> viewTransactionDetail(@PathVariable("accountNumber") int accountNumber)
	{
		return transactionService.viewTransactionDetail(accountNumber);
	}
}
